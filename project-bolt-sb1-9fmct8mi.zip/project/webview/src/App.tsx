import React, { useState, useEffect, useRef } from 'react';
import { Send, Paperclip, File, X } from 'lucide-react';
import { marked } from 'marked';

interface Message {
    id: string;
    type: 'user' | 'ai';
    content: string;
    timestamp: Date;
    attachedFiles?: string[];
}

interface WorkspaceFile {
    path: string;
    name: string;
}

interface AttachedFile {
    path: string;
    content: string;
}

declare global {
    interface Window {
        acquireVsCodeApi: () => any;
    }
}

const vscode = window.acquireVsCodeApi?.();

const App: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [inputText, setInputText] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [workspaceFiles, setWorkspaceFiles] = useState<WorkspaceFile[]>([]);
    const [attachedFiles, setAttachedFiles] = useState<AttachedFile[]>([]);
    const [showFileSuggestions, setShowFileSuggestions] = useState(false);
    const [fileSuggestions, setFileSuggestions] = useState<WorkspaceFile[]>([]);
    const [selectedSuggestionIndex, setSelectedSuggestionIndex] = useState(0);
    
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLTextAreaElement>(null);

    useEffect(() => {
        if (vscode) {
            vscode.postMessage({ type: 'getWorkspaceFiles' });
        }

        const handleMessage = (event: MessageEvent) => {
            const message = event.data;
            
            switch (message.type) {
                case 'aiResponse':
                    setIsLoading(false);
                    addMessage('ai', message.response);
                    break;
                case 'workspaceFiles':
                    setWorkspaceFiles(message.files);
                    break;
                case 'fileAttached':
                    setAttachedFiles(prev => [...prev, {
                        path: message.filePath,
                        content: message.content
                    }]);
                    break;
            }
        };

        window.addEventListener('message', handleMessage);
        return () => window.removeEventListener('message', handleMessage);
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const addMessage = (type: 'user' | 'ai', content: string, attachedFiles?: string[]) => {
        const newMessage: Message = {
            id: Date.now().toString(),
            type,
            content,
            timestamp: new Date(),
            attachedFiles
        };
        setMessages(prev => [...prev, newMessage]);
    };

    const handleSendMessage = () => {
        if (!inputText.trim() || isLoading) return;

        const attachedFilePaths = attachedFiles.map(f => f.path);
        addMessage('user', inputText, attachedFilePaths);

        if (vscode) {
            vscode.postMessage({
                type: 'sendMessage',
                text: inputText,
                attachedFiles: attachedFilePaths
            });
        }

        setInputText('');
        setAttachedFiles([]);
        setIsLoading(true);
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const text = e.target.value;
        setInputText(text);

        // Check for @ mentions
        const lastAtIndex = text.lastIndexOf('@');
        if (lastAtIndex !== -1) {
            const query = text.substring(lastAtIndex + 1).toLowerCase();
            const filteredFiles = workspaceFiles.filter(file =>
                file.name.toLowerCase().includes(query) ||
                file.path.toLowerCase().includes(query)
            );
            
            if (filteredFiles.length > 0) {
                setFileSuggestions(filteredFiles);
                setShowFileSuggestions(true);
                setSelectedSuggestionIndex(0);
            } else {
                setShowFileSuggestions(false);
            }
        } else {
            setShowFileSuggestions(false);
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (showFileSuggestions) {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setSelectedSuggestionIndex(prev => 
                    Math.min(prev + 1, fileSuggestions.length - 1)
                );
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                setSelectedSuggestionIndex(prev => Math.max(prev - 1, 0));
            } else if (e.key === 'Enter' || e.key === 'Tab') {
                e.preventDefault();
                selectFile(fileSuggestions[selectedSuggestionIndex]);
                return;
            } else if (e.key === 'Escape') {
                setShowFileSuggestions(false);
                return;
            }
        }

        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    };

    const selectFile = (file: WorkspaceFile) => {
        const lastAtIndex = inputText.lastIndexOf('@');
        const beforeAt = inputText.substring(0, lastAtIndex);
        const newText = beforeAt + `@${file.name} `;
        
        setInputText(newText);
        setShowFileSuggestions(false);
        
        // Attach the file
        if (vscode && !attachedFiles.some(f => f.path === file.path)) {
            vscode.postMessage({
                type: 'attachFile',
                filePath: file.path
            });
        }
        
        inputRef.current?.focus();
    };

    const removeAttachedFile = (path: string) => {
        setAttachedFiles(prev => prev.filter(f => f.path !== path));
    };

    const renderMessage = (message: Message) => {
        if (message.type === 'ai') {
            const htmlContent = marked(message.content);
            return (
                <div 
                    className="message-content"
                    dangerouslySetInnerHTML={{ __html: htmlContent }}
                />
            );
        }
        
        return <div className="message-content">{message.content}</div>;
    };

    const formatTime = (date: Date) => {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    };

    return (
        <div className="chat-container">
            <div className="chat-header">
                <h1>AI Chat Assistant</h1>
            </div>

            <div className="messages-container">
                {messages.map((message) => (
                    <div key={message.id} className={`message message-${message.type}`}>
                        {renderMessage(message)}
                        {message.attachedFiles && message.attachedFiles.length > 0 && (
                            <div className="attached-files">
                                {message.attachedFiles.map((filePath, index) => (
                                    <div key={index} className="attached-file">
                                        <File size={12} />
                                        <span>{filePath}</span>
                                    </div>
                                ))}
                            </div>
                        )}
                        <div className="message-timestamp">
                            {formatTime(message.timestamp)}
                        </div>
                    </div>
                ))}
                
                {isLoading && (
                    <div className="loading-indicator">
                        <span>AI is thinking</span>
                        <div className="loading-dots">
                            <div className="loading-dot"></div>
                            <div className="loading-dot"></div>
                            <div className="loading-dot"></div>
                        </div>
                    </div>
                )}
                
                <div ref={messagesEndRef} />
            </div>

            <div className="input-container">
                {attachedFiles.length > 0 && (
                    <div className="file-attachments">
                        {attachedFiles.map((file) => (
                            <div key={file.path} className="file-attachment">
                                <File size={12} />
                                <span>{file.path}</span>
                                <X 
                                    size={12} 
                                    className="file-attachment-remove"
                                    onClick={() => removeAttachedFile(file.path)}
                                />
                            </div>
                        ))}
                    </div>
                )}

                <div className="input-wrapper">
                    {showFileSuggestions && (
                        <div className="file-suggestions">
                            {fileSuggestions.map((file, index) => (
                                <div
                                    key={file.path}
                                    className={`file-suggestion ${index === selectedSuggestionIndex ? 'selected' : ''}`}
                                    onClick={() => selectFile(file)}
                                >
                                    <File size={14} />
                                    <span>{file.name}</span>
                                    <span style={{ opacity: 0.6, fontSize: '11px' }}>
                                        {file.path}
                                    </span>
                                </div>
                            ))}
                        </div>
                    )}

                    <textarea
                        ref={inputRef}
                        className="message-input"
                        value={inputText}
                        onChange={handleInputChange}
                        onKeyDown={handleKeyDown}
                        placeholder="Type your message... Use @filename to attach files"
                        disabled={isLoading}
                        rows={1}
                    />
                    
                    <button
                        className="send-button"
                        onClick={handleSendMessage}
                        disabled={!inputText.trim() || isLoading}
                    >
                        <Send size={16} />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default App;