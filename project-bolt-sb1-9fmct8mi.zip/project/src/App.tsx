import React, { useState, useEffect, useRef } from 'react';
import { Send, Paperclip, File, X } from 'lucide-react';
import { marked } from 'marked';

interface Message {
    id: string;
    type: 'user' | 'ai';
    content: string;
    timestamp: Date;
    attachedFiles?: string[];
}

interface WorkspaceFile {
    path: string;
    name: string;
}

interface AttachedFile {
    path: string;
    content: string;
}

declare global {
    interface Window {
        acquireVsCodeApi: () => any;
    }
}

const vscode = typeof window !== 'undefined' && window.acquireVsCodeApi?.();

const App: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [inputText, setInputText] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [workspaceFiles, setWorkspaceFiles] = useState<WorkspaceFile[]>([]);
    const [attachedFiles, setAttachedFiles] = useState<AttachedFile[]>([]);
    const [showFileSuggestions, setShowFileSuggestions] = useState(false);
    const [fileSuggestions, setFileSuggestions] = useState<WorkspaceFile[]>([]);
    const [selectedSuggestionIndex, setSelectedSuggestionIndex] = useState(0);
    
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLTextAreaElement>(null);

    useEffect(() => {
        if (vscode) {
            vscode.postMessage({ type: 'getWorkspaceFiles' });
        }

        const handleMessage = (event: MessageEvent) => {
            const message = event.data;
            
            switch (message.type) {
                case 'aiResponse':
                    setIsLoading(false);
                    addMessage('ai', message.response);
                    break;
                case 'workspaceFiles':
                    setWorkspaceFiles(message.files);
                    break;
                case 'fileAttached':
                    setAttachedFiles(prev => [...prev, {
                        path: message.filePath,
                        content: message.content
                    }]);
                    break;
            }
        };

        if (typeof window !== 'undefined') {
            window.addEventListener('message', handleMessage);
            return () => window.removeEventListener('message', handleMessage);
        }
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const addMessage = (type: 'user' | 'ai', content: string, attachedFiles?: string[]) => {
        const newMessage: Message = {
            id: Date.now().toString(),
            type,
            content,
            timestamp: new Date(),
            attachedFiles
        };
        setMessages(prev => [...prev, newMessage]);
    };

    const handleSendMessage = () => {
        if (!inputText.trim() || isLoading) return;

        const attachedFilePaths = attachedFiles.map(f => f.path);
        addMessage('user', inputText, attachedFilePaths);

        if (vscode) {
            vscode.postMessage({
                type: 'sendMessage',
                text: inputText,
                attachedFiles: attachedFilePaths
            });
        }

        setInputText('');
        setAttachedFiles([]);
        setIsLoading(true);
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const text = e.target.value;
        setInputText(text);

        // Check for @ mentions
        const lastAtIndex = text.lastIndexOf('@');
        if (lastAtIndex !== -1) {
            const query = text.substring(lastAtIndex + 1).toLowerCase();
            const filteredFiles = workspaceFiles.filter(file =>
                file.name.toLowerCase().includes(query) ||
                file.path.toLowerCase().includes(query)
            );
            
            if (filteredFiles.length > 0) {
                setFileSuggestions(filteredFiles);
                setShowFileSuggestions(true);
                setSelectedSuggestionIndex(0);
            } else {
                setShowFileSuggestions(false);
            }
        } else {
            setShowFileSuggestions(false);
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (showFileSuggestions) {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setSelectedSuggestionIndex(prev => 
                    Math.min(prev + 1, fileSuggestions.length - 1)
                );
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                setSelectedSuggestionIndex(prev => Math.max(prev - 1, 0));
            } else if (e.key === 'Enter' || e.key === 'Tab') {
                e.preventDefault();
                selectFile(fileSuggestions[selectedSuggestionIndex]);
                return;
            } else if (e.key === 'Escape') {
                setShowFileSuggestions(false);
                return;
            }
        }

        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    };

    const selectFile = (file: WorkspaceFile) => {
        const lastAtIndex = inputText.lastIndexOf('@');
        const beforeAt = inputText.substring(0, lastAtIndex);
        const newText = beforeAt + `@${file.name} `;
        
        setInputText(newText);
        setShowFileSuggestions(false);
        
        // Attach the file
        if (vscode && !attachedFiles.some(f => f.path === file.path)) {
            vscode.postMessage({
                type: 'attachFile',
                filePath: file.path
            });
        }
        
        inputRef.current?.focus();
    };

    const removeAttachedFile = (path: string) => {
        setAttachedFiles(prev => prev.filter(f => f.path !== path));
    };

    const renderMessage = (message: Message) => {
        if (message.type === 'ai') {
            const htmlContent = marked(message.content);
            return (
                <div 
                    className="message-content prose prose-sm max-w-none"
                    dangerouslySetInnerHTML={{ __html: htmlContent }}
                />
            );
        }
        
        return <div className="message-content">{message.content}</div>;
    };

    const formatTime = (date: Date) => {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    };

    return (
        <div className="flex flex-col h-screen bg-gray-50">
            <div className="flex-shrink-0 px-4 py-3 bg-white border-b border-gray-200">
                <h1 className="text-lg font-semibold text-gray-800">AI Chat Assistant</h1>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((message) => (
                    <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                            message.type === 'user' 
                                ? 'bg-blue-500 text-white' 
                                : 'bg-white text-gray-800 border border-gray-200'
                        }`}>
                            {renderMessage(message)}
                            {message.attachedFiles && message.attachedFiles.length > 0 && (
                                <div className="mt-2 space-y-1">
                                    {message.attachedFiles.map((filePath, index) => (
                                        <div key={index} className="flex items-center gap-1 text-xs opacity-75">
                                            <File size={12} />
                                            <span>{filePath}</span>
                                        </div>
                                    ))}
                                </div>
                            )}
                            <div className="text-xs opacity-60 mt-1">
                                {formatTime(message.timestamp)}
                            </div>
                        </div>
                    </div>
                ))}
                
                {isLoading && (
                    <div className="flex justify-start">
                        <div className="bg-white border border-gray-200 rounded-lg px-4 py-2">
                            <div className="flex items-center gap-2">
                                <span className="text-sm text-gray-600">AI is thinking</span>
                                <div className="flex gap-1">
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-75"></div>
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse delay-150"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
                
                <div ref={messagesEndRef} />
            </div>

            <div className="flex-shrink-0 p-4 bg-white border-t border-gray-200">
                {attachedFiles.length > 0 && (
                    <div className="mb-3 flex flex-wrap gap-2">
                        {attachedFiles.map((file) => (
                            <div key={file.path} className="flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                                <File size={12} />
                                <span>{file.path}</span>
                                <X 
                                    size={12} 
                                    className="cursor-pointer hover:text-blue-600"
                                    onClick={() => removeAttachedFile(file.path)}
                                />
                            </div>
                        ))}
                    </div>
                )}

                <div className="relative">
                    {showFileSuggestions && (
                        <div className="absolute bottom-full left-0 right-0 mb-2 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto z-10">
                            {fileSuggestions.map((file, index) => (
                                <div
                                    key={file.path}
                                    className={`flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-gray-50 ${
                                        index === selectedSuggestionIndex ? 'bg-blue-50 text-blue-700' : ''
                                    }`}
                                    onClick={() => selectFile(file)}
                                >
                                    <File size={14} />
                                    <div className="flex-1 min-w-0">
                                        <div className="text-sm font-medium truncate">{file.name}</div>
                                        <div className="text-xs text-gray-500 truncate">{file.path}</div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}

                    <div className="flex gap-2">
                        <textarea
                            ref={inputRef}
                            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            value={inputText}
                            onChange={handleInputChange}
                            onKeyDown={handleKeyDown}
                            placeholder="Type your message... Use @filename to attach files"
                            disabled={isLoading}
                            rows={1}
                        />
                        
                        <button
                            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                            onClick={handleSendMessage}
                            disabled={!inputText.trim() || isLoading}
                        >
                            <Send size={16} />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default App;