import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import Groq from 'groq-sdk';

export class ChatProvider implements vscode.WebviewViewProvider {
    public static readonly viewType = 'aiChatAssistant';
    private static _instance: ChatProvider | undefined;
    private _view?: vscode.WebviewView;
    private _groq: Groq;

    constructor(private readonly _extensionUri: vscode.Uri) {
        this._groq = new Groq({
            apiKey: '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'
        });
    }

    public static createOrShow(extensionUri: vscode.Uri) {
        const column = vscode.window.activeTextEditor
            ? vscode.window.activeTextEditor.viewColumn
            : undefined;

        if (ChatProvider._instance) {
            ChatProvider._instance._view?.show?.(true);
            return;
        }

        const panel = vscode.window.createWebviewPanel(
            ChatProvider.viewType,
            'AI Chat Assistant',
            column || vscode.ViewColumn.One,
            {
                enableScripts: true,
                retainContextWhenHidden: true,
                localResourceRoots: [
                    vscode.Uri.joinPath(extensionUri, 'out', 'webview')
                ]
            }
        );

        ChatProvider._instance = new ChatProvider(extensionUri);
        ChatProvider._instance._update(panel.webview, extensionUri);

        panel.onDidDispose(() => {
            ChatProvider._instance = undefined;
        }, null);

        panel.webview.onDidReceiveMessage(
            message => ChatProvider._instance?.handleMessage(message),
            undefined
        );
    }

    public resolveWebviewView(
        webviewView: vscode.WebviewView,
        context: vscode.WebviewViewResolveContext,
        _token: vscode.CancellationToken
    ) {
        this._view = webviewView;

        webviewView.webview.options = {
            enableScripts: true,
            localResourceRoots: [
                vscode.Uri.joinPath(this._extensionUri, 'out', 'webview')
            ]
        };

        webviewView.webview.html = this._getHtmlForWebview(webviewView.webview);

        webviewView.webview.onDidReceiveMessage(
            message => this.handleMessage(message),
            undefined
        );
    }

    private async handleMessage(message: any) {
        switch (message.type) {
            case 'sendMessage':
                await this.handleChatMessage(message.text, message.attachedFiles);
                break;
            case 'getWorkspaceFiles':
                await this.getWorkspaceFiles();
                break;
            case 'attachFile':
                await this.attachFile(message.filePath);
                break;
        }
    }

    private async handleChatMessage(text: string, attachedFiles: string[]) {
        try {
            let contextContent = '';
            
            // Add file contents to context
            for (const filePath of attachedFiles) {
                try {
                    const workspaceFolders = vscode.workspace.workspaceFolders;
                    if (workspaceFolders && workspaceFolders.length > 0) {
                        const fullPath = path.join(workspaceFolders[0].uri.fsPath, filePath);
                        const content = fs.readFileSync(fullPath, 'utf8');
                        contextContent += `\n\n--- File: ${filePath} ---\n${content}`;
                    }
                } catch (error) {
                    console.error(`Error reading file ${filePath}:`, error);
                }
            }

            const systemPrompt = `You are an AI coding assistant integrated into VS Code. You help with code generation, debugging, and explanations. 
            
Current workspace context:${contextContent}

Provide helpful, accurate responses. When generating code, use appropriate syntax highlighting with markdown code blocks.`;

            const completion = await this._groq.chat.completions.create({
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: text }
                ],
                model: 'llama3-8b-8192',
                temperature: 0.7,
                max_tokens: 2048,
            });

            const response = completion.choices[0]?.message?.content || 'Sorry, I could not generate a response.';

            this._view?.webview.postMessage({
                type: 'aiResponse',
                response: response
            });

        } catch (error) {
            console.error('Error calling Groq API:', error);
            this._view?.webview.postMessage({
                type: 'aiResponse',
                response: 'Sorry, there was an error processing your request.'
            });
        }
    }

    private async getWorkspaceFiles() {
        const workspaceFolders = vscode.workspace.workspaceFolders;
        if (!workspaceFolders || workspaceFolders.length === 0) {
            return;
        }

        const files = await vscode.workspace.findFiles(
            '**/*.{ts,tsx,js,jsx,py,java,cpp,c,h,css,html,json,md,txt}',
            '**/node_modules/**'
        );

        const fileList = files.map(file => {
            const relativePath = vscode.workspace.asRelativePath(file);
            return {
                path: relativePath,
                name: path.basename(relativePath)
            };
        });

        this._view?.webview.postMessage({
            type: 'workspaceFiles',
            files: fileList
        });
    }

    private async attachFile(filePath: string) {
        try {
            const workspaceFolders = vscode.workspace.workspaceFolders;
            if (workspaceFolders && workspaceFolders.length > 0) {
                const fullPath = path.join(workspaceFolders[0].uri.fsPath, filePath);
                const content = fs.readFileSync(fullPath, 'utf8');
                
                this._view?.webview.postMessage({
                    type: 'fileAttached',
                    filePath,
                    content: content.substring(0, 1000) // Preview first 1000 chars
                });
            }
        } catch (error) {
            console.error(`Error attaching file ${filePath}:`, error);
        }
    }

    private _update(webview: vscode.Webview, extensionUri: vscode.Uri) {
        webview.html = this._getHtmlForWebview(webview);
    }

    private _getHtmlForWebview(webview: vscode.Webview) {
        const scriptUri = webview.asWebviewUri(
            vscode.Uri.joinPath(this._extensionUri, 'out', 'webview', 'assets', 'main.js')
        );
        const styleUri = webview.asWebviewUri(
            vscode.Uri.joinPath(this._extensionUri, 'out', 'webview', 'assets', 'main.css')
        );

        const nonce = getNonce();

        return `<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src ${webview.cspSource} https:; script-src 'nonce-${nonce}'; style-src ${webview.cspSource} 'unsafe-inline';">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link href="${styleUri}" rel="stylesheet">
                <title>AI Chat Assistant</title>
            </head>
            <body>
                <div id="root"></div>
                <script nonce="${nonce}" src="${scriptUri}"></script>
            </body>
            </html>`;
    }
}

function getNonce() {
    let text = '';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < 32; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
}