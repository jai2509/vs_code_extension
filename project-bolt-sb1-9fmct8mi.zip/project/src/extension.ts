import * as vscode from 'vscode';
import { ChatProvider } from './chatProvider';

export function activate(context: vscode.ExtensionContext) {
    const provider = new ChatProvider(context.extensionUri);

    context.subscriptions.push(
        vscode.window.registerWebviewViewProvider(ChatProvider.viewType, provider)
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('aiChatAssistant.openChat', () => {
            ChatProvider.createOrShow(context.extensionUri);
        })
    );
}

export function deactivate() {}